package com.affanhost.finalproject01;

public class User {
    public String fullname, username, email, password;

    public User() {
    }

    public User(String fullname, String username, String email) {
        this.fullname = fullname;
        this.username = username;
        this.email = email;
    }


}
